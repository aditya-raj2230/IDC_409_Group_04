# lpr > 2022-05-30 1:47pm
https://universe.roboflow.com/cv-detection/lpr-yaicp

Provided by a Roboflow user
License: CC BY 4.0

